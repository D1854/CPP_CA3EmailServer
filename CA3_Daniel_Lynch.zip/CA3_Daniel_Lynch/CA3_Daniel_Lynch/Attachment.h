#pragma once
class Attachment
{
public:
	Attachment();
	~Attachment();
};

