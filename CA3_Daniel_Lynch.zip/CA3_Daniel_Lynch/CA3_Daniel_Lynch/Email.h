#pragma once
#include <string>
#include <ctime>
#include <vector>
#include "Attachment.h"

//datetime Assistance : https://www.tutorialspoint.com/cplusplus/cpp_date_time.htm

class Email
{
public:
	//black constructor (When user creates a new email)
	Email();

	//constructor with date (this is from when emails are read in from file)
	Email(std::string sender, std::string subject, std::string body,
		std::vector<std::string> recipient, std::vector<Attachment>, std::string dateAsString);


	~Email();

	//setters, add and remove
	void setSender(std::string &sender);
	void setSubject(std::string &subject);
	void setBody(std::string &body);
	void addRecipient(std::string &rec);
	void removeRecipient(int pos) { Email::recipient.erase(Email::recipient.begin() + pos); }
	void setRecipient(std::vector<std::string> & recList);
	void addAttachment(Attachment &att) { Email::attachment.push_back(att); }
	void setAttachment(std::vector<Attachment> attachment) { Email::attachment = attachment; }
	void removeAttachment(int pos) { Email::attachment.erase(Email::attachment.begin() + pos); }
	void setDateAsString(std::string date) { Email::dateAsString = date; }
	//time
	//date

	//getters
	std::string getSender() { return Email::sender; }
	std::string getSubject() { return Email::subject; }
	std::string getBody() { return Email::body; }
	std::vector<std::string> getRecipients() { return Email::recipient; }
	std::string getRecipient(int pos) { return Email::recipient[pos]; }
	std::string getDateAsString() { return Email::dateAsString; }


	//utility
	bool checkValidEmail(const std::string& email);



private:
	std::string sender, subject, body, dateAsString;
	std::vector<std::string> recipient;
	std::vector<Attachment> attachment;

	time_t time;
	char* date;
};

