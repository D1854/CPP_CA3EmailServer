#pragma once
class UserList
{
public:
	UserList();
	~UserList();
};

