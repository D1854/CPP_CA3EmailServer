#include "Attachment.h"



Attachment::Attachment()
{
}


Attachment::~Attachment()
{
}
