#include "EmailList.h"



EmailList::EmailList()
{
}


EmailList::~EmailList()
{
}
