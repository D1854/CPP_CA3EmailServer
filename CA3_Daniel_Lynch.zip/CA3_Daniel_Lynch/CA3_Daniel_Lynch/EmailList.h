#pragma once
class EmailList
{
public:
	EmailList();
	~EmailList();
};

