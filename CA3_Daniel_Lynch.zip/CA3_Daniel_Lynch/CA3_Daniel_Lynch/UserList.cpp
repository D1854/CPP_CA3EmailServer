#include "UserList.h"



UserList::UserList()
{
}


UserList::~UserList()
{
}
