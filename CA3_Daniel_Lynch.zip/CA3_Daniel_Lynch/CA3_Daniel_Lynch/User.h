#pragma once
#include<string>

class User
{
public:
	User();
	User(std::string address, std::string password, std::string username);
	~User();

	//getters
	std::string getAddress() { return User::address; }
	std::string getPassword() { return User::password; }
	std::string getUsername() { return User::password; }

	//setters
	void setAddress(std::string add);
	void setPassword(std::string password);
	void setUsername(std::string username);

	//print

	bool User::checkValidEmail(const std::string & email);


private:
	std::string address, password, username;
};

