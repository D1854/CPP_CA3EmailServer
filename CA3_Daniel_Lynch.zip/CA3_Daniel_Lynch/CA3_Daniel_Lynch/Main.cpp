
/*
	Author: Daniel Lynch - D00160870
	Assignment : CA3 - Email server
	Start date : 06/12/2016


	The program starts off assuming that the user
	has logged into a admin account.
	
	Completed:	> Created Classes
				> Created most of getters and setters for email

	ToDo:		> Finish getters and setters for classes
				> impliment validation
				> create constructors
				> create menu system

	--------------------------------------------------------------------------------

	Update : 07/12/2016 - Daniel 

	Completed:	> Added Validation to Email class
				

	ToDo:		> create Full and half constructor for email
				> create menu system
				> create other classes


	---------------------------------------------------------------------------------

	Update : 08/12/2016



*/




#include <string>
#include <iostream>

using namespace std;

int main() {


	//initialize stuff or whatever

	
	

	system("pause");
	return 0;
}