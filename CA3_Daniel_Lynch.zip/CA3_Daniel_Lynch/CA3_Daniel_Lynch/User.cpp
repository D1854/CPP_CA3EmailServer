#include "User.h"
#include <regex>
#include <iostream>



User::User()
{
}

User::User(std::string address, std::string password, std::string username)
{
	//setaddress
	//serpaswrod
	//setuser name
}


User::~User()
{
}

void User::setAddress(std::string add)
{
	if (checkValidEmail(add))
		User::address = add;
	else
		std::cout << "Invalid user address" << std::endl;
	//regex validate
}

void User::setPassword(std::string password)
{
	//> 8, num and digit
}

void User::setUsername(std::string username)
{
	// > 8
}


bool User::checkValidEmail(const std::string & email)
{
	// pattern that looks for "@" and a "."
	const std::regex pattern
		("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");

	// try to match the string with the regular expression
	return std::regex_match(email, pattern);
}
