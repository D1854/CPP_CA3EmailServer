#include <regex>
#include <iostream>
#include "Email.h"



Email::Email()
{
}

Email::Email(std::string sender, std::string subject, std::string body, std::vector<std::string> recipient, std::vector<Attachment> attachment, std::string dateAsString)
{
	setSender(sender);
	setSubject(subject);
	setBody(body);
	setRecipient(recipient);
	setAttachment(attachment);
	setDateAsString(dateAsString);
}


Email::~Email()
{
}

void Email::setSender(std::string & sender)
{
	//check that email is valid before setting
	if (checkValidEmail(sender))
		Email::sender = sender;
	else
		std::cout << "Sender email not valid " << std::endl;
}

void Email::setSubject(std::string & subject)
{
	//check that subject is not empty
	if (!subject.empty())
		Email::subject = subject;
	else
		std::cout << "No subject" << std::endl;

}

void Email::setBody(std::string & body)
{
	if (!body.empty())
		Email::body = body;
	else
		std::cout << "Body empty" << std::endl;
}

void Email::addRecipient(std::string & rec)
{
	//check that email is valid before adding it to the vector
	if (checkValidEmail(rec))
		Email::recipient.push_back(rec);
	else
		std::cout << "Not valid recipient email" << std::endl;
}

void Email::setRecipient(std::vector<std::string>& recList)
{
	Email::recipient = recList;

	/* - this is more of an "Add multiple" class than a set class

	//for every email in the list
	for (std::string rec : recList)
		addRecipient(rec); //piggy back off the add validation

		*/
}


bool Email::checkValidEmail(const std::string & email)
{
	// pattern that looks for "@" and a "."
	const std::regex pattern
		("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");

	// try to match the string with the regular expression
	return std::regex_match(email, pattern);
}
